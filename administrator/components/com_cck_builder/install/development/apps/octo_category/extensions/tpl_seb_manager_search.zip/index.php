<?php
/**
* @version 			SEBLOD 3.x More
* @package			SEBLOD (App Builder & CCK) // SEBLOD nano (Form Builder)
* @url				https://www.seblod.com
* @editor			Octopoos - www.octopoos.com
* @copyright		Copyright (C) 2009 - 2018 SEBLOD. All Rights Reserved.
* @license 			GNU General Public License version 2 or later; see _LICENSE.php
**/

defined( '_JEXEC' ) or die;

// -- Initialize
require_once __DIR__.'/config.php';
$cck	=	CCK_Rendering::getInstance( $this->template );
if ( $cck->initialize() === false ) { return; }

// -- Prepare
$attributes	=	$cck->id_attributes ? ' '.$cck->id_attributes : '';
$attributes	=	$cck->replaceLive( $attributes );

// -- Render
if ( $cck->id_class != '' ) {
	echo '<div class="'.trim( $cck->id_class ).'"'.$attributes.'>';
}

echo '<div class="o-form manager">';

// Toolbar
$toolbar	=	$cck->renderPosition( 'toolbar', 'octo_toolbar' );
$toolbar_3	=	$cck->renderPosition( 'toolbar_3', 'octo_button' );

echo '<div class="o-toolbar">'.$toolbar;

if ( $toolbar_3 ) {
	echo '<div class="o-colstart-6 o-btngroup o-align-jse">'.$toolbar_3.'</div>';
}

echo '</div>';

// Filters
$filter1	=	$cck->renderPosition( 'filter1', 'octo_filter' );
$filter1_2	=	$cck->renderPosition( 'filter1_2', 'octo_filter' );
$filter1_3	=	$cck->renderPosition( 'filter1_3', 'octo_filter' );

echo '<div class="o-form o-col-6@auto default-search" has-value>'.$filter1;

if ( $filter1_2 ) {
	echo '<div class="o-colstart-5@n">'.$filter1_2.'</div>';
}

if ( $filter1_3 ) {
	echo '<div class="o-colstart-6@n">'.$filter1_3.'</div>';
}

echo '</div>';

// Filters: Advanced
$filter2	=	$cck->renderPosition( 'filter2', 'octo_filter' );
$filter2_3	=	$cck->renderPosition( 'filter2_3', 'octo_filter' );

if ( $filter2 ) {
	echo '<div class="o-grid o-rgap-16 advanced-search">'
		.'<div class="o-form o-col-6@auto" has-value>'.$filter2.'</div>';

	if ( $filter2_3 ) {
		echo '<div class="o-grid">'.$filter2_3.'</div>';
	}

	echo '</div>';
}

echo '</div>';

// Info
$info1		=	$cck->renderPosition( 'info1' );
$info1_2	=	$cck->renderPosition( 'info1_2' );

echo '<div class="o-form o-col-6@auto infos-search o-align-ic@n o-align-jc@n" has-value>'.$info1;

if ( $info1_2 ) {
	echo '<div class="o-colstart-6">'.$info1_2.'</div>';
}

echo '</div>';

if ( $cck->id_class != '' ) {
	echo '</div>';
}

for ( $i = 1; $i <= 5; $i++ ) {
	$suffix	=	( $i == 1 ) ? '' : $i;
	if ( $cck->countFields( 'modal'.$suffix ) ) {
		JHtml::_( 'bootstrap.modal', 'collapseModal'.$suffix );

		$class = $cck->getPosition( 'modal'.$suffix )->css;
		$class = ( $class ) ? ' ' . $class : '';
		?>
		<div class="modal hide fade<?php echo $class; ?>" id="collapseModal<?php echo $suffix; ?>">
			<?php echo $cck->renderPosition( 'modal'.$suffix ); ?>
		</div>
	<?php }
}

if ( $cck->countFields( 'hidden' ) && ( $buffer = $cck->renderPosition( 'hidden' ) ) ) { ?>
	<div style="display: none;">
		<?php echo $buffer; ?>
	</div>
<?php }

// -- Finalize
$cck->finalize();
?>